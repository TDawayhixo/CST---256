<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UseerModel;
use App\Services\Business\SecurityService;


class LoginController extends Controller
{
    
    
    //To obtain an instance of the current HTTP request from a post
    
    public function index(Request $request)
    {
       // $formValues = $request->all();
       // $userName = request()->get('user_name');
        
       // return $request->all();
    
        
        
        //step d in activity2
        $credentials = new UseerModel(request()->get('user_name'),request()->get('password'));
        
        // Business logic layer
        $serviceLogin = new SecurityService();
        
        //Business logic layer credentials
        $isValid = $serviceLogin->login($credentials);
        
        if($isValid)
        {
            return view('loginPass');
        }
        else
        {
            return view('loginFailed');
        }
        
        
    }
}