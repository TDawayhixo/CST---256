<?php

namespace App\Services\Business;

use App\Models\UseerModel;
use App\Services\Data\SecurityDAO;

class SecurityService
{
    //properties
    private $verfyCred;
    
    public function login(UseerModel $credentials)
    {
        //data access layer
        $this->verfyCred = new SecurityDAO();
        
        return $this->verfyCred->findByuser($credentials);
    }
}