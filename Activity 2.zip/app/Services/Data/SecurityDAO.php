<?php

namespace App\Services\Data;

use App\Models\UseerModel;
use Carbon\Exceptions\Exception;

class SecurityDAO
{
   private $conn;
   private $servername = "localhost";
   private $username = "root";
   private $password = "root";
   private $dbname = "activity2";
   private $dbQuery;
   private $port = "8889";
   
   public function __construct()
   {
       
       //Creating a connection to database
       $this->conn = mysqli_connect($this->servername, $this->username, $this->password, $this->dbname, $this->port);
       //make sure to test connection for errors
   }
   
   //method to verify user credentials
   public function findByuser(UseerModel $credentials) 
   {
       try {
           $this->dbQuery = "SELECT Username, Password FROM users WHERE Username = '{$credentials->getUsername()}' AND Password = '{$credentials->getPassword()}'"; 
           
           $result = mysqli_query($this->conn, $this->dbQuery);
           
           if (mysqli_num_rows($result) > 0)
           {
               return true;
           }else
           {
               return false;
           }
       } catch (Exception $e) 
       {
           echo $e->getMessage();
       };
   }
}