<?php

namespace App\Models;

class UseerModel 
{
    private $username;
    private $password;
    
    
    public function __construct($username, $password) 
    {
        $this->username = $username;
        $this->password = $password;
        
    }
    
    /**
     * getter method -> username
     * @return string
     */
    public function getUsername() 
    {
        return $this->username;
        
    }
    
    public function getPassword() 
    {
        return $this->password;
    }
}