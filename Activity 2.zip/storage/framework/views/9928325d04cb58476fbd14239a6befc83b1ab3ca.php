<?php $__env->startSection('title', 'Login Page'); ?>

<?php $__env->startSection('content'); ?>
<html>
<head>
	<title>User Login</title>
</head>
<body>
	<div>
		<form action="dologin" method="post"> 
			<?php echo e(csrf_field()); ?>

			<!-- Table Div -->
			<div class="demo-table">
				<div class="form-head">Login</div>
				<!-- Begin Username -->
				<div class="form-column">
					<div>
						<label for="username">Username</label><span id="user_info" class="error-info"></span>
						<input name="user_name" id="user_name" type="text" class="demoo-input-box">
						</div>
					</div>
					<!-- Begin Password -->
				<div class="form-column">
					<div>
						<label for="password">Password</label><span id="password_info" class="error-info"></span>
						<input name="password" id="password" type="text" class="demoo-input-box">
						</div>
					</div>
					<!-- End Password -->
					<div>
						<input type="submit" class="btnlogin">
					</div>
				</div>
				<!-- End Table -->
			</form>
		</div>
	</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ultra\eclipse-workspace\Activity 2.1\resources\views/login2.blade.php ENDPATH**/ ?>