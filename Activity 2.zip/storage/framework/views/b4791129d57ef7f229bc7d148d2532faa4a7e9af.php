<html>
Login Pass
</html>
<?php /**PATH C:\Users\ultra\eclipse-workspace\Activity 2.1\resources\views/loginPass.blade.php ENDPATH**/ ?>