
<body>
	<h2> Hello!</h2>
		<?php echo $firstName . " " . $lastName; ?>
		<br>
		<a href="askme">Go Again</a>
</body>

<?php /**PATH C:\Users\ultra\eclipse-workspace\Activity 2.1\resources\views/thatswhoami.blade.php ENDPATH**/ ?>