<html>
Login Failed
</html>
<?php /**PATH C:\Users\ultra\eclipse-workspace\Activity 2.1\resources\views/loginFailed.blade.php ENDPATH**/ ?>